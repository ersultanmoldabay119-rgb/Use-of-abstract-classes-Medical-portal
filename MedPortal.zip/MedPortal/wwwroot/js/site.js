﻿// Поиск по выпадающему списку: <input data-filter-select="#idSelect">
document.querySelectorAll('[data-filter-select]').forEach(input => {
    const select = document.querySelector(input.dataset.filterSelect);
    if (!select) return;

    input.addEventListener('input', () => {
        const term = input.value.trim().toLowerCase();
        let firstMatch = null;

        select.querySelectorAll('option').forEach(opt => {
            if (!opt.value || opt.value === '0') return; // пункт «— выберите —» оставляем
            const match = !term || opt.text.toLowerCase().includes(term);
            opt.hidden = !match;
            if (match && !firstMatch) firstMatch = opt;
        });

        select.querySelectorAll('optgroup').forEach(g => {
            g.hidden = ![...g.querySelectorAll('option')].some(o => !o.hidden);
        });

        // Если выбранный пункт скрыт фильтром — выбираем первое совпадение
        const selected = select.options[select.selectedIndex];
        if (term && firstMatch && (!selected || selected.hidden || !selected.value || selected.value === '0')) {
            select.value = firstMatch.value;
        }
    });
});

// Подтверждение удаления: <form data-confirm="Текст">
document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', e => {
        if (!confirm(form.dataset.confirm)) e.preventDefault();
    });
});
