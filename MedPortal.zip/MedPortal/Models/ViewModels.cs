using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MedPortal.Models;

public class LoginViewModel
{
    [Display(Name = "ИИН пациента или логин врача")]
    [Required(ErrorMessage = "Введите ИИН или логин")]
    public string Login { get; set; } = "";

    [Display(Name = "Пароль")]
    [Required(ErrorMessage = "Введите пароль")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Display(Name = "Запомнить меня")]
    public bool RememberMe { get; set; }

    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Display(Name = "ФИО врача")]
    [Required(ErrorMessage = "Укажите ФИО")]
    [StringLength(150)]
    public string FullName { get; set; } = "";

    [Display(Name = "Специальность")]
    [Required(ErrorMessage = "Укажите специальность")]
    [StringLength(100)]
    public string Specialty { get; set; } = "";

    [Display(Name = "Медицинская организация")]
    [StringLength(200)]
    public string? Organization { get; set; }

    [Display(Name = "Логин")]
    [Required(ErrorMessage = "Придумайте логин")]
    [RegularExpression(@"^[a-zA-Z0-9_.]{3,50}$", ErrorMessage = "Логин: 3–50 символов, латиница, цифры, точка или _")]
    public string Login { get; set; } = "";

    [Display(Name = "Пароль")]
    [Required(ErrorMessage = "Придумайте пароль")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Пароль должен быть не короче 6 символов")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Display(Name = "Повторите пароль")]
    [Required(ErrorMessage = "Повторите пароль")]
    [Compare(nameof(Password), ErrorMessage = "Пароли не совпадают")]
    [DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
}

public class ProfileViewModel
{
    [ValidateNever]
    public string Login { get; set; } = "";

    [Display(Name = "ФИО врача")]
    [Required(ErrorMessage = "Укажите ФИО")]
    [StringLength(150)]
    public string FullName { get; set; } = "";

    [Display(Name = "Специальность")]
    [Required(ErrorMessage = "Укажите специальность")]
    [StringLength(100)]
    public string Specialty { get; set; } = "";

    [Display(Name = "Медицинская организация")]
    [StringLength(200)]
    public string? Organization { get; set; }

    [Display(Name = "Кабинет приёма")]
    [StringLength(20)]
    public string? Room { get; set; }

    [Display(Name = "Провожу онлайн-консультации")]
    public bool IsOnlineAvailable { get; set; }

    [Display(Name = "Ссылка на видеокомнату (необязательно)")]
    [StringLength(300)]
    public string? OnlineConsultationUrl { get; set; }

    [Display(Name = "Текущий пароль")]
    [DataType(DataType.Password)]
    public string? CurrentPassword { get; set; }

    [Display(Name = "Новый пароль")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Пароль должен быть не короче 6 символов")]
    [DataType(DataType.Password)]
    public string? NewPassword { get; set; }

    [Display(Name = "Повторите новый пароль")]
    [Compare(nameof(NewPassword), ErrorMessage = "Пароли не совпадают")]
    [DataType(DataType.Password)]
    public string? ConfirmPassword { get; set; }
}

public record TopDiagnosisItem(string Code, string Name, int Count);

public class DashboardViewModel
{
    public Doctor Doctor { get; set; } = null!;
    public int TotalRecords { get; set; }
    public int PatientsCount { get; set; }
    public int ThisMonth { get; set; }
    public int ActiveCount { get; set; }
    public int FavoritesCount { get; set; }
    public List<PatientDiagnosis> Recent { get; set; } = new();
    public List<TopDiagnosisItem> Top { get; set; } = new();
    public int TodayAppointments { get; set; }
    public List<Appointment> Upcoming { get; set; } = new();
}

/// <summary>Форма постановки / редактирования диагноза.</summary>
public class RecordFormViewModel
{
    public int Id { get; set; }

    [Display(Name = "Пациент")]
    [Range(1, int.MaxValue, ErrorMessage = "Выберите пациента")]
    public int PatientId { get; set; }

    [Display(Name = "Диагноз (МКБ-10)")]
    [Range(1, int.MaxValue, ErrorMessage = "Выберите диагноз")]
    public int DiagnosisId { get; set; }

    [Display(Name = "Дата и время постановки")]
    [Required(ErrorMessage = "Укажите дату")]
    public DateTime DiagnosedAt { get; set; } = DateTime.Now;

    [Display(Name = "Тип диагноза")]
    public DiagnosisType Type { get; set; } = DiagnosisType.Final;

    [Display(Name = "Статус")]
    public DiagnosisStatus Status { get; set; } = DiagnosisStatus.Active;

    [Display(Name = "Комментарий / жалобы / назначения")]
    [StringLength(1000)]
    public string? Comment { get; set; }

    /// <summary>Запись на приём, по которой ставится диагноз (после сохранения приём отмечается состоявшимся).</summary>
    public int? AppointmentId { get; set; }

    [ValidateNever] public List<SelectListItem> Patients { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Diagnoses { get; set; } = new();
}

/// <summary>Список диагнозов врача + параметры фильтра (приходят из query string).</summary>
public class RecordListViewModel
{
    public const int PageSize = 15;

    public string? Search { get; set; }
    public int? DiagnosisId { get; set; }
    public string? Category { get; set; }
    public DiagnosisType? Type { get; set; }
    public DiagnosisStatus? Status { get; set; }
    public DateOnly? DateFrom { get; set; }
    public DateOnly? DateTo { get; set; }
    public string? Sort { get; set; }
    public int PageNo { get; set; } = 1;

    [ValidateNever] public List<PatientDiagnosis> Items { get; set; } = new();
    [ValidateNever] public List<SelectListItem> DiagnosisOptions { get; set; } = new();
    [ValidateNever] public List<SelectListItem> CategoryOptions { get; set; } = new();
    public int Total { get; set; }
    public int TotalPages { get; set; }

    public bool IsFiltered =>
        !string.IsNullOrWhiteSpace(Search) || DiagnosisId.HasValue || !string.IsNullOrEmpty(Category) ||
        Type.HasValue || Status.HasValue || DateFrom.HasValue || DateTo.HasValue;

    /// <summary>Параметры текущего фильтра для ссылок пагинации/сортировки.</summary>
    public Dictionary<string, string> RouteValues(int? pageNo = null, string? sort = null)
    {
        var d = new Dictionary<string, string>();
        void Add(string key, string? value)
        {
            if (!string.IsNullOrEmpty(value)) d[key] = value;
        }

        Add(nameof(Search), Search);
        Add(nameof(DiagnosisId), DiagnosisId?.ToString());
        Add(nameof(Category), Category);
        Add(nameof(Type), Type.HasValue ? ((int)Type.Value).ToString() : null);
        Add(nameof(Status), Status.HasValue ? ((int)Status.Value).ToString() : null);
        Add(nameof(DateFrom), DateFrom?.ToString("yyyy-MM-dd"));
        Add(nameof(DateTo), DateTo?.ToString("yyyy-MM-dd"));
        Add(nameof(Sort), sort ?? Sort);
        Add(nameof(PageNo), (pageNo ?? PageNo).ToString());
        return d;
    }
}

public class PatientListItem
{
    public Patient Patient { get; set; } = null!;
    public int MyRecords { get; set; }
    public DateTime? LastVisit { get; set; }
}

public class PatientListViewModel
{
    public string? Search { get; set; }
    public bool OnlyMine { get; set; }
    [ValidateNever] public List<PatientListItem> Items { get; set; } = new();
}

public class PatientDetailsViewModel
{
    public Patient Patient { get; set; } = null!;
    public List<PatientDiagnosis> Records { get; set; } = new();
}

public class CatalogItem
{
    public Diagnosis Diagnosis { get; set; } = null!;
    public bool IsFavorite { get; set; }
    public int UsedCount { get; set; }
    public bool IsCustom => Diagnosis.OwnerDoctorId.HasValue;
}

/// <summary>Справочник МКБ-10 с выбором «моих» диагнозов.</summary>
public class CatalogViewModel
{
    public string? Search { get; set; }
    public string? Category { get; set; }
    public bool OnlyMine { get; set; }

    [ValidateNever] public List<CatalogItem> Items { get; set; } = new();
    [ValidateNever] public List<SelectListItem> CategoryOptions { get; set; } = new();
    public int FavoritesCount { get; set; }
}

// =====================================================================
//  Приёмы (врач) и кабинет пациента
// =====================================================================

/// <summary>Расписание приёмов врача + фильтр.</summary>
public class DoctorAppointmentsViewModel
{
    /// <summary>upcoming — предстоящие, today — сегодня, past — прошедшие, all — все.</summary>
    public string? Period { get; set; }
    public DateOnly? Date { get; set; }
    public AppointmentStatus? Status { get; set; }
    public string? Search { get; set; }

    [ValidateNever] public List<Appointment> Items { get; set; } = new();
    public int TodayCount { get; set; }
    public int UpcomingCount { get; set; }
}

public class PatientRegisterViewModel
{
    [Display(Name = "ФИО")]
    [Required(ErrorMessage = "Укажите ФИО")]
    [StringLength(150)]
    public string FullName { get; set; } = "";

    [Display(Name = "ИИН")]
    [Required(ErrorMessage = "Укажите ИИН")]
    [RegularExpression(@"^\d{12}$", ErrorMessage = "ИИН должен состоять из 12 цифр")]
    public string Iin { get; set; } = "";

    [Display(Name = "Дата рождения")]
    [DataType(DataType.Date)]
    [Required(ErrorMessage = "Укажите дату рождения")]
    public DateOnly? BirthDate { get; set; }

    [Display(Name = "Пол")]
    public Gender Gender { get; set; }

    [Display(Name = "Телефон")]
    [Required(ErrorMessage = "Укажите телефон")]
    [StringLength(30)]
    public string Phone { get; set; } = "";

    [Display(Name = "Пароль")]
    [Required(ErrorMessage = "Придумайте пароль")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Пароль должен быть не короче 6 символов")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Display(Name = "Повторите пароль")]
    [Required(ErrorMessage = "Повторите пароль")]
    [Compare(nameof(Password), ErrorMessage = "Пароли не совпадают")]
    [DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
}

/// <summary>Главная страница кабинета пациента.</summary>
public class PatientHomeViewModel
{
    public Patient Patient { get; set; } = null!;
    public List<Appointment> Upcoming { get; set; } = new();
    public List<PatientDiagnosis> RecentDiagnoses { get; set; } = new();
    public int UpcomingCount { get; set; }
    public int DiagnosesCount { get; set; }
    public int ActiveCount { get; set; }
    public int DoctorsCount { get; set; }
}

/// <summary>Диагнозы пациента (от всех врачей) + фильтр.</summary>
public class PatientDiagnosesViewModel
{
    public string? Search { get; set; }
    public int? DoctorId { get; set; }
    public DiagnosisStatus? Status { get; set; }
    public DateOnly? DateFrom { get; set; }
    public DateOnly? DateTo { get; set; }

    [ValidateNever] public List<PatientDiagnosis> Items { get; set; } = new();
    [ValidateNever] public List<SelectListItem> DoctorOptions { get; set; } = new();
    public int Total { get; set; }

    public bool IsFiltered =>
        !string.IsNullOrWhiteSpace(Search) || DoctorId.HasValue || Status.HasValue || DateFrom.HasValue || DateTo.HasValue;
}

public class PatientAppointmentsViewModel
{
    public List<Appointment> Upcoming { get; set; } = new();
    public List<Appointment> Past { get; set; } = new();
}

public record BookDay(DateOnly Date, int FreeCount);
public record BookSlot(DateTime Time, bool IsFree);

/// <summary>Запись на приём: врач → день → время.</summary>
public class BookViewModel
{
    public string? Specialty { get; set; }
    public int? DoctorId { get; set; }
    public DateOnly? Date { get; set; }

    /// <summary>Выбранное время приёма (приходит из формы).</summary>
    public DateTime? StartsAt { get; set; }

    [Display(Name = "Формат приёма")]
    public bool IsOnline { get; set; }

    [Display(Name = "Причина обращения")]
    [StringLength(500)]
    public string? Reason { get; set; }

    [ValidateNever] public List<Doctor> Doctors { get; set; } = new();
    [ValidateNever] public List<string> Specialties { get; set; } = new();
    [ValidateNever] public Doctor? Doctor { get; set; }
    [ValidateNever] public List<BookDay> Days { get; set; } = new();
    [ValidateNever] public List<BookSlot> Slots { get; set; } = new();
}

/// <summary>«Мои данные»: пациент меняет контакты и пароль, остальное — только просмотр.</summary>
public class PatientProfileViewModel
{
    [ValidateNever] public Patient Patient { get; set; } = null!;

    [Display(Name = "Телефон")]
    [Required(ErrorMessage = "Укажите телефон")]
    [StringLength(30)]
    public string? Phone { get; set; }

    [Display(Name = "E-mail")]
    [EmailAddress(ErrorMessage = "Некорректный e-mail")]
    [StringLength(120)]
    public string? Email { get; set; }

    [Display(Name = "Адрес")]
    [StringLength(250)]
    public string? Address { get; set; }

    [Display(Name = "Текущий пароль")]
    [DataType(DataType.Password)]
    public string? CurrentPassword { get; set; }

    [Display(Name = "Новый пароль")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Пароль должен быть не короче 6 символов")]
    [DataType(DataType.Password)]
    public string? NewPassword { get; set; }

    [Display(Name = "Повторите новый пароль")]
    [Compare(nameof(NewPassword), ErrorMessage = "Пароли не совпадают")]
    [DataType(DataType.Password)]
    public string? ConfirmPassword { get; set; }
}
