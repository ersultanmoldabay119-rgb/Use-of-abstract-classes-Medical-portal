using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

/// <summary>
/// Диагнозы, поставленные врачом. Каждый врач видит и редактирует только свои записи.
/// </summary>
[Authorize(Roles = Roles.Doctor)]
public class RecordsController(AppDbContext db) : Controller
{
    private int Me => User.GetDoctorId();

    // ---------- Список + фильтр ----------
    public async Task<IActionResult> Index(RecordListViewModel vm)
    {
        var me = Me;
        var q = db.Records
            .Include(r => r.Patient)
            .Include(r => r.Diagnosis)
            .Where(r => r.DoctorId == me);

        if (!string.IsNullOrWhiteSpace(vm.Search))
        {
            var s = vm.Search.Trim().ToLowerInvariant();
            q = q.Where(r => r.Patient!.FullNameLower.Contains(s) || r.Patient.Iin.Contains(s));
        }
        if (vm.DiagnosisId.HasValue)
            q = q.Where(r => r.DiagnosisId == vm.DiagnosisId);
        if (!string.IsNullOrEmpty(vm.Category))
            q = q.Where(r => r.Diagnosis!.Category == vm.Category);
        if (vm.Type.HasValue)
            q = q.Where(r => r.Type == vm.Type);
        if (vm.Status.HasValue)
            q = q.Where(r => r.Status == vm.Status);
        if (vm.DateFrom.HasValue)
        {
            var from = vm.DateFrom.Value.ToDateTime(TimeOnly.MinValue);
            q = q.Where(r => r.DiagnosedAt >= from);
        }
        if (vm.DateTo.HasValue)
        {
            var to = vm.DateTo.Value.AddDays(1).ToDateTime(TimeOnly.MinValue);
            q = q.Where(r => r.DiagnosedAt < to);
        }

        q = vm.Sort switch
        {
            "date_asc" => q.OrderBy(r => r.DiagnosedAt),
            "patient" => q.OrderBy(r => r.Patient!.FullName).ThenByDescending(r => r.DiagnosedAt),
            "patient_desc" => q.OrderByDescending(r => r.Patient!.FullName).ThenByDescending(r => r.DiagnosedAt),
            "code" => q.OrderBy(r => r.Diagnosis!.Code).ThenByDescending(r => r.DiagnosedAt),
            "code_desc" => q.OrderByDescending(r => r.Diagnosis!.Code).ThenByDescending(r => r.DiagnosedAt),
            _ => q.OrderByDescending(r => r.DiagnosedAt)
        };

        vm.Total = await q.CountAsync();
        vm.TotalPages = Math.Max(1, (int)Math.Ceiling(vm.Total / (double)RecordListViewModel.PageSize));
        vm.PageNo = Math.Clamp(vm.PageNo, 1, vm.TotalPages);
        vm.Items = await q.Skip((vm.PageNo - 1) * RecordListViewModel.PageSize)
            .Take(RecordListViewModel.PageSize).ToListAsync();

        // В фильтре «Диагноз» — только те диагнозы, которые этот врач ставил
        var used = await db.Records.Where(r => r.DoctorId == me)
            .Select(r => r.Diagnosis!).Distinct()
            .OrderBy(d => d.Code).ToListAsync();
        vm.DiagnosisOptions = used.Select(d => new SelectListItem(d.Title, d.Id.ToString())).ToList();
        vm.CategoryOptions = used.Select(d => d.Category).Distinct().Order()
            .Select(c => new SelectListItem(c, c)).ToList();

        return View(vm);
    }

    // ---------- Поставить диагноз ----------
    [HttpGet]
    public async Task<IActionResult> Create(int? patientId, int? diagnosisId, int? appointmentId)
    {
        var vm = new RecordFormViewModel
        {
            PatientId = patientId ?? 0,
            DiagnosisId = diagnosisId ?? 0,
            DiagnosedAt = DateTime.Now
        };

        // Диагноз по итогам приёма: пациент подставляется из записи
        if (appointmentId.HasValue)
        {
            var me = Me;
            var appointment = await db.Appointments
                .FirstOrDefaultAsync(a => a.Id == appointmentId && a.DoctorId == me);
            if (appointment != null)
            {
                vm.AppointmentId = appointment.Id;
                vm.PatientId = appointment.PatientId;
                if (!string.IsNullOrEmpty(appointment.Reason)) vm.Comment = "Жалобы: " + appointment.Reason;
            }
        }

        await FillListsAsync(vm);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(RecordFormViewModel vm)
    {
        await ValidateReferencesAsync(vm);
        if (!ModelState.IsValid)
        {
            await FillListsAsync(vm);
            return View(vm);
        }

        var record = new PatientDiagnosis { DoctorId = Me };
        Apply(vm, record);
        db.Records.Add(record);

        // Если диагноз поставлен по записи на приём — отмечаем приём состоявшимся
        var fromAppointment = false;
        if (vm.AppointmentId.HasValue)
        {
            var me = Me;
            var appointment = await db.Appointments.FirstOrDefaultAsync(a =>
                a.Id == vm.AppointmentId && a.DoctorId == me && a.PatientId == vm.PatientId);
            if (appointment != null)
            {
                fromAppointment = true;
                if (appointment.Status == AppointmentStatus.Scheduled && appointment.StartsAt.Date <= DateTime.Today)
                    appointment.Status = AppointmentStatus.Completed;
            }
        }

        await db.SaveChangesAsync();

        TempData["Success"] = "Диагноз поставлен";
        return fromAppointment
            ? RedirectToAction("Index", "Appointments")
            : RedirectToAction(nameof(Index));
    }

    // ---------- Редактирование ----------
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var r = await FindMineAsync(id);
        if (r == null) return NotFound();

        var vm = new RecordFormViewModel
        {
            Id = r.Id,
            PatientId = r.PatientId,
            DiagnosisId = r.DiagnosisId,
            DiagnosedAt = r.DiagnosedAt,
            Type = r.Type,
            Status = r.Status,
            Comment = r.Comment
        };
        await FillListsAsync(vm);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, RecordFormViewModel vm)
    {
        var r = await FindMineAsync(id);
        if (r == null) return NotFound();

        await ValidateReferencesAsync(vm);
        if (!ModelState.IsValid)
        {
            vm.Id = id;
            await FillListsAsync(vm);
            return View(vm);
        }

        Apply(vm, r);
        await db.SaveChangesAsync();
        TempData["Success"] = "Изменения сохранены";
        return RedirectToAction(nameof(Index));
    }

    // ---------- Удаление ----------
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id, string? returnUrl)
    {
        var r = await FindMineAsync(id);
        if (r == null) return NotFound();

        db.Records.Remove(r);
        await db.SaveChangesAsync();
        TempData["Success"] = "Запись удалена";

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
        return RedirectToAction(nameof(Index));
    }

    // ---------- Вспомогательное ----------
    private Task<PatientDiagnosis?> FindMineAsync(int id)
    {
        var me = Me;
        return db.Records.FirstOrDefaultAsync(r => r.Id == id && r.DoctorId == me);
    }

    private static void Apply(RecordFormViewModel vm, PatientDiagnosis r)
    {
        r.PatientId = vm.PatientId;
        r.DiagnosisId = vm.DiagnosisId;
        r.DiagnosedAt = vm.DiagnosedAt;
        r.Type = vm.Type;
        r.Status = vm.Status;
        r.Comment = string.IsNullOrWhiteSpace(vm.Comment) ? null : vm.Comment.Trim();
    }

    private async Task ValidateReferencesAsync(RecordFormViewModel vm)
    {
        var me = Me;
        if (vm.PatientId > 0 && !await db.Patients.AnyAsync(p => p.Id == vm.PatientId))
            ModelState.AddModelError(nameof(vm.PatientId), "Пациент не найден");
        if (vm.DiagnosisId > 0 && !await db.Diagnoses.AnyAsync(d =>
                d.Id == vm.DiagnosisId && (d.OwnerDoctorId == null || d.OwnerDoctorId == me)))
            ModelState.AddModelError(nameof(vm.DiagnosisId), "Диагноз не найден");
        if (vm.DiagnosedAt > DateTime.Now.AddMinutes(5))
            ModelState.AddModelError(nameof(vm.DiagnosedAt), "Дата не может быть в будущем");
    }

    /// <summary>
    /// Списки для формы. Диагнозы из личного справочника врача идут первой группой,
    /// затем остальной справочник МКБ-10.
    /// </summary>
    private async Task FillListsAsync(RecordFormViewModel vm)
    {
        var me = Me;
        vm.Patients = (await db.Patients.OrderBy(p => p.FullName).ToListAsync())
            .Select(p => new SelectListItem($"{p.FullName} — ИИН {p.Iin}", p.Id.ToString()))
            .ToList();

        var favIds = await db.Favorites.Where(f => f.DoctorId == me).Select(f => f.DiagnosisId).ToListAsync();
        var all = await db.Diagnoses
            .Where(d => d.OwnerDoctorId == null || d.OwnerDoctorId == me)
            .OrderBy(d => d.Code).ToListAsync();

        var mine = new SelectListGroup { Name = "★ Мои диагнозы" };
        var rest = new SelectListGroup { Name = "Справочник МКБ-10" };
        vm.Diagnoses = all.Where(d => favIds.Contains(d.Id))
            .Select(d => new SelectListItem(d.Title, d.Id.ToString()) { Group = mine })
            .Concat(all.Where(d => !favIds.Contains(d.Id))
                .Select(d => new SelectListItem(d.Title, d.Id.ToString()) { Group = rest }))
            .ToList();
    }
}
