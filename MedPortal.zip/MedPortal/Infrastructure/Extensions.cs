using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Security.Claims;
using MedPortal.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace MedPortal.Infrastructure;

/// <summary>Роли пользователей портала.</summary>
public static class Roles
{
    public const string Doctor = "Doctor";
    public const string Patient = "Patient";
}

public static class UserExtensions
{
    private static int GetId(ClaimsPrincipal user) =>
        int.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>Id врача, вошедшего в систему.</summary>
    public static int GetDoctorId(this ClaimsPrincipal user) =>
        user.IsInRole(Roles.Doctor) ? GetId(user) : throw new InvalidOperationException("Пользователь не является врачом");

    /// <summary>Id пациента, вошедшего в систему.</summary>
    public static int GetPatientId(this ClaimsPrincipal user) =>
        user.IsInRole(Roles.Patient) ? GetId(user) : throw new InvalidOperationException("Пользователь не является пациентом");

    public static bool IsDoctor(this ClaimsPrincipal user) => user.IsInRole(Roles.Doctor);
    public static bool IsPatient(this ClaimsPrincipal user) => user.IsInRole(Roles.Patient);

    /// <summary>Подпись под именем в меню: специальность врача или «Пациент».</summary>
    public static string Subtitle(this ClaimsPrincipal user) =>
        user.FindFirstValue("Subtitle") ?? "";
}

public static class AuthHelper
{
    public static Task SignInDoctorAsync(HttpContext http, Doctor doctor, bool persistent) =>
        SignInAsync(http, doctor.Id, doctor.FullName, Roles.Doctor, doctor.Specialty, persistent);

    public static Task SignInPatientAsync(HttpContext http, Patient patient, bool persistent) =>
        SignInAsync(http, patient.Id, patient.FullName, Roles.Patient, "Пациент", persistent);

    private static Task SignInAsync(HttpContext http, int id, string name, string role, string subtitle, bool persistent)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, id.ToString()),
            new(ClaimTypes.Name, name),
            new(ClaimTypes.Role, role),
            new("Subtitle", subtitle)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        return http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            new AuthenticationProperties { IsPersistent = persistent });
    }
}

public static class EnumExtensions
{
    public static string DisplayName(this Enum value) =>
        value.GetType().GetMember(value.ToString()).FirstOrDefault()?
            .GetCustomAttribute<DisplayAttribute>()?.GetName() ?? value.ToString();

    public static string BadgeClass(this DiagnosisStatus status) => status switch
    {
        DiagnosisStatus.Active => "text-bg-warning",
        DiagnosisStatus.Chronic => "text-bg-danger",
        DiagnosisStatus.Recovered => "text-bg-success",
        _ => "text-bg-secondary"
    };

    public static string BadgeClass(this DiagnosisType type) => type switch
    {
        DiagnosisType.Final => "badge-soft-primary",
        DiagnosisType.Preliminary => "badge-soft-secondary",
        DiagnosisType.Concomitant => "badge-soft-info",
        _ => "badge-soft-secondary"
    };

    public static string BadgeClass(this AppointmentStatus status) => status switch
    {
        AppointmentStatus.Scheduled => "badge-soft-primary",
        AppointmentStatus.Completed => "text-bg-success",
        AppointmentStatus.Cancelled => "badge-soft-secondary",
        AppointmentStatus.NoShow => "text-bg-danger",
        _ => "badge-soft-secondary"
    };
}

public static class TextExtensions
{
    /// <summary>Только цифры телефона, последние 10 (без +7 / 8) — для сравнения номеров.</summary>
    public static string PhoneDigits(this string? phone)
    {
        var digits = new string((phone ?? "").Where(char.IsDigit).ToArray());
        return digits.Length > 10 ? digits[^10..] : digits;
    }

    /// <summary>«Сейткали Арман Бауржанович» → «Арман» (для приветствия).</summary>
    public static string FirstName(this string fullName)
    {
        var parts = fullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return parts.Length > 1 ? parts[1] : fullName;
    }

    /// <summary>«четверг, 12 ноября» с заглавной буквы.</summary>
    public static string ToLongDay(this DateTime date)
    {
        var s = date.ToString("dddd, d MMMM");
        return char.ToUpper(s[0]) + s[1..];
    }
}
