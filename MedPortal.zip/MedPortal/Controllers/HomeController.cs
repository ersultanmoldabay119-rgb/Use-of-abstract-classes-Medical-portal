using System.Diagnostics;
using MedPortal.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using MedPortal.Models;

namespace MedPortal.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        // Вошедшего пользователя сразу ведём в его кабинет
        if (User.IsDoctor()) return RedirectToAction("Index", "Cabinet");
        if (User.IsPatient()) return RedirectToAction("Index", "My");
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
