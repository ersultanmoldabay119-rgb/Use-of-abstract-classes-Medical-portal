using MedPortal.Models;
using Microsoft.AspNetCore.Identity;

namespace MedPortal.Data;

/// <summary>Заполняет пустую БД справочником МКБ-10, демо-врачами, пациентами и диагнозами.</summary>
public static class DbSeeder
{
    public const string DemoPassword = "123456";

    private static readonly (string Code, string Name, string Category)[] Icd10 =
    [
        ("A09", "Диарея и гастроэнтерит предположительно инфекционного происхождения", "Инфекционные и паразитарные болезни (A00–B99)"),
        ("B01.9", "Ветряная оспа без осложнений", "Инфекционные и паразитарные болезни (A00–B99)"),
        ("B34.9", "Вирусная инфекция неуточнённая", "Инфекционные и паразитарные болезни (A00–B99)"),
        ("D50.9", "Железодефицитная анемия неуточнённая", "Болезни крови и кроветворных органов (D50–D89)"),
        ("E03.9", "Гипотиреоз неуточнённый", "Болезни эндокринной системы (E00–E90)"),
        ("E04.2", "Нетоксический многоузловой зоб", "Болезни эндокринной системы (E00–E90)"),
        ("E05.0", "Тиреотоксикоз с диффузным зобом", "Болезни эндокринной системы (E00–E90)"),
        ("E10.9", "Инсулинзависимый сахарный диабет без осложнений", "Болезни эндокринной системы (E00–E90)"),
        ("E11.9", "Инсулиннезависимый сахарный диабет без осложнений", "Болезни эндокринной системы (E00–E90)"),
        ("E66.0", "Ожирение, обусловленное избыточным поступлением энергетических ресурсов", "Болезни эндокринной системы (E00–E90)"),
        ("E78.0", "Чистая гиперхолестеринемия", "Болезни эндокринной системы (E00–E90)"),
        ("F32.9", "Депрессивный эпизод неуточнённый", "Психические расстройства (F00–F99)"),
        ("F41.1", "Генерализованное тревожное расстройство", "Психические расстройства (F00–F99)"),
        ("G43.9", "Мигрень неуточнённая", "Болезни нервной системы (G00–G99)"),
        ("G44.2", "Головная боль напряжённого типа", "Болезни нервной системы (G00–G99)"),
        ("G47.0", "Нарушения засыпания и поддержания сна (бессонница)", "Болезни нервной системы (G00–G99)"),
        ("H10.9", "Конъюнктивит неуточнённый", "Болезни глаза, уха и сосцевидного отростка (H00–H95)"),
        ("H52.1", "Миопия", "Болезни глаза, уха и сосцевидного отростка (H00–H95)"),
        ("H66.9", "Средний отит неуточнённый", "Болезни глаза, уха и сосцевидного отростка (H00–H95)"),
        ("I10", "Эссенциальная (первичная) гипертензия", "Болезни системы кровообращения (I00–I99)"),
        ("I11.9", "Гипертензивная болезнь сердца без застойной сердечной недостаточности", "Болезни системы кровообращения (I00–I99)"),
        ("I20.8", "Другие формы стенокардии", "Болезни системы кровообращения (I00–I99)"),
        ("I21.9", "Острый инфаркт миокарда неуточнённый", "Болезни системы кровообращения (I00–I99)"),
        ("I25.1", "Атеросклеротическая болезнь сердца", "Болезни системы кровообращения (I00–I99)"),
        ("I48", "Фибрилляция и трепетание предсердий", "Болезни системы кровообращения (I00–I99)"),
        ("I50.0", "Застойная сердечная недостаточность", "Болезни системы кровообращения (I00–I99)"),
        ("I63.9", "Инфаркт мозга неуточнённый", "Болезни системы кровообращения (I00–I99)"),
        ("I83.9", "Варикозное расширение вен нижних конечностей без язвы или воспаления", "Болезни системы кровообращения (I00–I99)"),
        ("J00", "Острый назофарингит (насморк)", "Болезни органов дыхания (J00–J99)"),
        ("J02.9", "Острый фарингит неуточнённый", "Болезни органов дыхания (J00–J99)"),
        ("J03.9", "Острый тонзиллит неуточнённый", "Болезни органов дыхания (J00–J99)"),
        ("J06.9", "Острая инфекция верхних дыхательных путей неуточнённая (ОРВИ)", "Болезни органов дыхания (J00–J99)"),
        ("J18.9", "Пневмония неуточнённая", "Болезни органов дыхания (J00–J99)"),
        ("J20.9", "Острый бронхит неуточнённый", "Болезни органов дыхания (J00–J99)"),
        ("J44.9", "Хроническая обструктивная лёгочная болезнь неуточнённая", "Болезни органов дыхания (J00–J99)"),
        ("J45.9", "Астма неуточнённая", "Болезни органов дыхания (J00–J99)"),
        ("K21.0", "Гастроэзофагеальный рефлюкс с эзофагитом", "Болезни органов пищеварения (K00–K93)"),
        ("K25.9", "Язва желудка неуточнённая", "Болезни органов пищеварения (K00–K93)"),
        ("K29.7", "Гастрит неуточнённый", "Болезни органов пищеварения (K00–K93)"),
        ("K35.8", "Острый аппендицит, другой и неуточнённый", "Болезни органов пищеварения (K00–K93)"),
        ("K80.2", "Камни желчного пузыря без холецистита", "Болезни органов пищеварения (K00–K93)"),
        ("K81.1", "Хронический холецистит", "Болезни органов пищеварения (K00–K93)"),
        ("K85.9", "Острый панкреатит неуточнённый", "Болезни органов пищеварения (K00–K93)"),
        ("L20.9", "Атопический дерматит неуточнённый", "Болезни кожи и подкожной клетчатки (L00–L99)"),
        ("L50.0", "Аллергическая крапивница", "Болезни кожи и подкожной клетчатки (L00–L99)"),
        ("M17.9", "Гонартроз неуточнённый", "Болезни костно-мышечной системы (M00–M99)"),
        ("M42.1", "Остеохондроз позвоночника у взрослых", "Болезни костно-мышечной системы (M00–M99)"),
        ("M54.5", "Боль внизу спины", "Болезни костно-мышечной системы (M00–M99)"),
        ("M81.0", "Постменопаузный остеопороз", "Болезни костно-мышечной системы (M00–M99)"),
        ("N10", "Острый тубулоинтерстициальный нефрит (острый пиелонефрит)", "Болезни мочеполовой системы (N00–N99)"),
        ("N18.9", "Хроническая болезнь почки неуточнённая", "Болезни мочеполовой системы (N00–N99)"),
        ("N20.0", "Камни почки", "Болезни мочеполовой системы (N00–N99)"),
        ("N30.0", "Острый цистит", "Болезни мочеполовой системы (N00–N99)"),
        ("U07.1", "COVID-19, вирус идентифицирован", "Коды для особых целей (U00–U85)"),
    ];

    public static void Seed(AppDbContext db)
    {
        if (!db.Doctors.Any()) SeedBase(db);
        SeedPatientPortal(db);
        SeedOnlineConsultations(db);
    }

    private static void SeedBase(AppDbContext db)
    {

        // 1. Справочник МКБ-10
        var diagnoses = Icd10.Select(x => new Diagnosis { Code = x.Code, Name = x.Name, Category = x.Category }).ToList();
        db.Diagnoses.AddRange(diagnoses);

        // 2. Демо-врачи
        var hasher = new PasswordHasher<Doctor>();
        Doctor MakeDoctor(string login, string name, string specialty) =>
            new()
            {
                Login = login,
                FullName = name,
                Specialty = specialty,
                Organization = "ГКП на ПХВ «Городская поликлиника №5», г. Алматы"
            };

        var therapist = MakeDoctor("terapevt", "Ахметова Айгерим Сериковна", "Врач общей практики (терапевт)");
        var cardiologist = MakeDoctor("kardiolog", "Жумабеков Нурлан Ерланович", "Кардиолог");
        var endocrinologist = MakeDoctor("endokrinolog", "Ким Елена Викторовна", "Эндокринолог");
        var doctors = new[] { therapist, cardiologist, endocrinologist };
        foreach (var d in doctors) d.PasswordHash = hasher.HashPassword(d, DemoPassword);
        db.Doctors.AddRange(doctors);

        // 3. Личный выбор диагнозов у каждого врача
        Diagnosis D(string code) => diagnoses.First(x => x.Code == code);
        void Fav(Doctor doc, params string[] codes)
        {
            foreach (var c in codes) db.Favorites.Add(new DoctorFavorite { Doctor = doc, Diagnosis = D(c) });
        }

        Fav(therapist, "J06.9", "J02.9", "J20.9", "I10", "K29.7", "M54.5", "A09", "B34.9", "D50.9", "N30.0", "G44.2", "U07.1");
        Fav(cardiologist, "I10", "I11.9", "I20.8", "I25.1", "I48", "I50.0", "I83.9", "E78.0");
        Fav(endocrinologist, "E03.9", "E04.2", "E05.0", "E10.9", "E11.9", "E66.0", "E78.0");

        // Личный (нестандартный) диагноз — пример «своего» диагноза врача
        var custom = new Diagnosis
        {
            Code = "R73.0",
            Name = "Нарушение толерантности к глюкозе (преддиабет)",
            Category = "Симптомы и отклонения от нормы (R00–R99)",
            OwnerDoctor = endocrinologist
        };
        db.Diagnoses.Add(custom);
        db.Favorites.Add(new DoctorFavorite { Doctor = endocrinologist, Diagnosis = custom });

        // 4. Пациенты
        var patients = new List<Patient>
        {
            P("Сейткали Арман Бауржанович", "850314300123", 1985, 3, 14, Gender.Male, "+7 701 123 45 67", "г. Алматы, ул. Абая, 150, кв. 12"),
            P("Нурланова Дана Маратовна", "920721400456", 1992, 7, 21, Gender.Female, "+7 707 234 56 78", "г. Алматы, мкр. Самал-2, 45"),
            P("Иванов Сергей Петрович", "670105300789", 1967, 1, 5, Gender.Male, "+7 705 345 67 89", "г. Алматы, ул. Толе би, 89"),
            P("Омарова Гульнара Кайратовна", "750930401234", 1975, 9, 30, Gender.Female, "+7 777 456 78 90", "г. Алматы, пр. Достык, 210"),
            P("Тулегенов Ержан Асланович", "010612500567", 2001, 6, 12, Gender.Male, "+7 702 567 89 01", "г. Алматы, ул. Сатпаева, 30"),
            P("Ли Анастасия Олеговна", "880227400890", 1988, 2, 27, Gender.Female, "+7 708 678 90 12", "г. Алматы, мкр. Орбита-3, 17"),
            P("Абдрахманов Тимур Серикович", "590818300345", 1959, 8, 18, Gender.Male, "+7 701 789 01 23", "г. Алматы, ул. Жандосова, 58"),
            P("Касымова Алия Нурбековна", "151103600678", 2015, 11, 3, Gender.Female, "+7 747 890 12 34", "г. Алматы, мкр. Аксай-4, 66"),
            P("Петрова Мария Ивановна", "540402400912", 1954, 4, 2, Gender.Female, "+7 705 901 23 45", "г. Алматы, ул. Розыбакиева, 247"),
            P("Бекмуханов Данияр Ержанович", "970915300234", 1997, 9, 15, Gender.Male, "+7 776 012 34 56", "г. Алматы, ул. Тимирязева, 42"),
            P("Жакупова Сауле Амангельдыевна", "800506400567", 1980, 5, 6, Gender.Female, "+7 701 112 23 34", "г. Алматы, ул. Гагарина, 135"),
            P("Ким Виктор Александрович", "720120300890", 1972, 1, 20, Gender.Male, "+7 707 223 34 45", "г. Алматы, мкр. Мамыр-1, 8"),
        };
        db.Patients.AddRange(patients);

        // 5. Диагнозы, поставленные врачами (у каждого — свои)
        var rnd = new Random(42);
        string[] comments =
        [
            "Жалобы на слабость, повышение температуры. Назначено лечение, повторный приём через 7 дней.",
            "Состояние удовлетворительное. Рекомендовано наблюдение.",
            "Направлен(а) на ОАК, ОАМ, биохимию крови.",
            "Назначена медикаментозная терапия, контроль АД ежедневно.",
            "Повторный осмотр. Положительная динамика.",
            "Рекомендована консультация узкого специалиста.",
            null!
        ];

        void AddRecords(Doctor doc, string[] codes, int count)
        {
            for (var i = 0; i < count; i++)
            {
                var date = DateTime.Today.AddDays(-rnd.Next(0, 120)).AddHours(rnd.Next(8, 18)).AddMinutes(rnd.Next(0, 4) * 15);
                var code = codes[rnd.Next(codes.Length)];
                var diag = code == "R73.0" ? custom : D(code);
                db.Records.Add(new PatientDiagnosis
                {
                    Doctor = doc,
                    Patient = patients[rnd.Next(patients.Count)],
                    Diagnosis = diag,
                    DiagnosedAt = date,
                    CreatedAt = date,
                    Type = (DiagnosisType)rnd.Next(0, 3),
                    Status = (DiagnosisStatus)rnd.Next(0, 3),
                    Comment = comments[rnd.Next(comments.Length)]
                });
            }
        }

        AddRecords(therapist, ["J06.9", "J02.9", "J20.9", "I10", "K29.7", "M54.5", "A09", "B34.9", "D50.9", "N30.0", "G44.2", "U07.1"], 28);
        AddRecords(cardiologist, ["I10", "I11.9", "I20.8", "I25.1", "I48", "I50.0", "E78.0"], 18);
        AddRecords(endocrinologist, ["E03.9", "E04.2", "E05.0", "E11.9", "E66.0", "R73.0"], 16);

        db.SaveChanges();
    }

    /// <summary>
    /// Демо-данные кабинета пациента: пароли демо-пациентов, данные карты, кабинеты врачей и записи на приём.
    /// Выполняется один раз — в том числе для базы, созданной прежней версией сайта.
    /// </summary>
    private static void SeedPatientPortal(AppDbContext db)
    {
        if (db.Appointments.Any() || db.Patients.Any(p => p.PasswordHash != null)) return;

        // Кабинеты демо-врачей
        var rooms = new Dictionary<string, string> { ["terapevt"] = "204", ["kardiolog"] = "312", ["endokrinolog"] = "215" };
        var demoLogins = rooms.Keys.ToArray();
        var demoDoctors = db.Doctors.Where(d => demoLogins.Contains(d.Login)).ToList();
        foreach (var d in demoDoctors.Where(d => string.IsNullOrEmpty(d.Room))) d.Room = rooms[d.Login];

        // Личные кабинеты и данные карты демо-пациентов
        string[] demoIins =
        [
            "850314300123", "920721400456", "670105300789", "750930401234", "010612500567", "880227400890",
            "590818300345", "151103600678", "540402400912", "970915300234", "800506400567", "720120300890"
        ];
        string[] blood = ["O(I) Rh+", "A(II) Rh+", "B(III) Rh+", "AB(IV) Rh+", "A(II) Rh−", "O(I) Rh−"];
        string?[] allergies = [null, "Пенициллин", null, "Пыльца берёзы, цитрусовые", null, "Ибупрофен"];
        var hasher = new PasswordHasher<Patient>();
        var demoPatients = db.Patients.Where(p => demoIins.Contains(p.Iin)).OrderBy(p => p.Id).ToList();
        for (var i = 0; i < demoPatients.Count; i++)
        {
            var p = demoPatients[i];
            p.PasswordHash = hasher.HashPassword(p, DemoPassword);
            p.BloodGroup ??= blood[i % blood.Length];
            p.Allergies ??= allergies[i % allergies.Length];
            p.Email ??= $"patient{p.Id}@example.com";
        }

        // Записи на приём: прошедшие и предстоящие
        if (demoDoctors.Count > 0 && demoPatients.Count > 0)
        {
            var rnd = new Random(7);
            string?[] reasons =
            [
                "Повышенная температура и кашель третий день", "Плановый осмотр", "Скачки давления по вечерам",
                "Повторный приём, результаты анализов", "Боли в спине", "Головные боли", "Получить справку", null
            ];
            var today = DateOnly.FromDateTime(DateTime.Today);
            var pastDays = Enumerable.Range(1, 20).Select(i => today.AddDays(-i)).Where(Infrastructure.Schedule.IsWorkDay).ToList();
            var futureDays = Infrastructure.Schedule.BookableDays().Where(d => d > today).ToList();
            var busyDoctor = new HashSet<(int, DateTime)>();
            var busyPatient = new HashSet<(int, DateTime)>();

            void Add(Doctor doc, DateOnly day, AppointmentStatus status)
            {
                var slots = Infrastructure.Schedule.SlotsFor(day);
                var time = slots[rnd.Next(slots.Count)];
                var patient = demoPatients[rnd.Next(demoPatients.Count)];
                if (!busyDoctor.Add((doc.Id, time)) || !busyPatient.Add((patient.Id, time))) return;
                db.Appointments.Add(new Appointment
                {
                    Doctor = doc, Patient = patient, StartsAt = time, Status = status,
                    Reason = reasons[rnd.Next(reasons.Length)], CreatedAt = time.AddDays(-3)
                });
            }

            foreach (var doc in demoDoctors)
            {
                for (var i = 0; i < 8; i++)
                    Add(doc, pastDays[rnd.Next(pastDays.Count)], rnd.Next(6) == 0 ? AppointmentStatus.NoShow : AppointmentStatus.Completed);
                for (var i = 0; i < 9; i++)
                    Add(doc, futureDays[rnd.Next(futureDays.Count)], AppointmentStatus.Scheduled);
            }
        }

        db.SaveChanges();
    }

    /// <summary>
    /// Заполняет демо-данные онлайн-консультаций (IOnlineConsultation) для существующей или новой базы.
    /// </summary>
    private static void SeedOnlineConsultations(AppDbContext db)
    {
        if (db.Appointments.Any(a => a.IsOnline)) return;

        var doctors = db.Doctors.ToDictionary(d => d.Id);
        var appointments = db.Appointments.OrderBy(a => a.Id).ToList();
        for (var i = 0; i < appointments.Count; i++)
        {
            if (i % 3 != 0) continue;
            var a = appointments[i];
            if (!doctors.TryGetValue(a.DoctorId, out var doc) || !doc.IsOnlineAvailable) continue;
            a.IsOnline = true;
            a.OnlineLink = doc.BuildConsultationLink(a.StartsAt);
        }

        db.SaveChanges();
    }

    private static Patient P(string name, string iin, int y, int m, int d, Gender g, string phone, string address) =>
        new() { FullName = name, Iin = iin, BirthDate = new DateOnly(y, m, d), Gender = g, Phone = phone, Address = address };
}
