namespace MedPortal.Infrastructure;

/// <summary>
/// Расписание приёма (одинаковое для всех врачей):
/// пн–пт, 09:00–13:00 и 14:00–18:00, приём длится 30 минут.
/// </summary>
public static class Schedule
{
    public const int SlotMinutes = 30;

    /// <summary>На сколько дней вперёд открыта запись.</summary>
    public const int DaysAhead = 14;

    private static readonly TimeOnly[] SlotTimes = BuildSlots();

    private static TimeOnly[] BuildSlots()
    {
        var list = new List<TimeOnly>();
        for (var t = new TimeOnly(9, 0); t < new TimeOnly(13, 0); t = t.AddMinutes(SlotMinutes)) list.Add(t);
        for (var t = new TimeOnly(14, 0); t < new TimeOnly(18, 0); t = t.AddMinutes(SlotMinutes)) list.Add(t);
        return list.ToArray();
    }

    public static bool IsWorkDay(DateOnly date) =>
        date.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday);

    /// <summary>Рабочие дни, на которые сейчас можно записаться.</summary>
    public static List<DateOnly> BookableDays()
    {
        var today = DateOnly.FromDateTime(DateTime.Today);
        return Enumerable.Range(0, DaysAhead + 1)
            .Select(today.AddDays)
            .Where(IsWorkDay)
            .ToList();
    }

    /// <summary>Все времена приёма в указанный день (без учёта занятости).</summary>
    public static List<DateTime> SlotsFor(DateOnly date) =>
        IsWorkDay(date) ? SlotTimes.Select(date.ToDateTime).ToList() : new List<DateTime>();

    /// <summary>Можно ли записаться на это время (рабочий слот, в будущем, в пределах окна записи).</summary>
    public static bool IsBookable(DateTime startsAt)
    {
        var date = DateOnly.FromDateTime(startsAt);
        var today = DateOnly.FromDateTime(DateTime.Today);
        return startsAt > DateTime.Now
               && date <= today.AddDays(DaysAhead)
               && SlotsFor(date).Contains(startsAt);
    }
}
