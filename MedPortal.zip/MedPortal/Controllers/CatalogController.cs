using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

/// <summary>
/// Справочник МКБ-10. Врач выбирает «свои» диагнозы (с которыми работает)
/// и может добавить личные диагнозы, которые видит только он.
/// </summary>
[Authorize(Roles = Roles.Doctor)]
public class CatalogController(AppDbContext db) : Controller
{
    private int Me => User.GetDoctorId();

    public async Task<IActionResult> Index(CatalogViewModel vm)
    {
        var me = Me;
        var favIds = await db.Favorites.Where(f => f.DoctorId == me).Select(f => f.DiagnosisId).ToListAsync();
        var visible = db.Diagnoses.Where(d => d.OwnerDoctorId == null || d.OwnerDoctorId == me);
        var q = visible;

        if (!string.IsNullOrWhiteSpace(vm.Search))
        {
            var s = vm.Search.Trim().ToLowerInvariant();
            q = q.Where(d => d.SearchText.Contains(s));
        }
        if (!string.IsNullOrEmpty(vm.Category))
            q = q.Where(d => d.Category == vm.Category);
        if (vm.OnlyMine)
            q = q.Where(d => favIds.Contains(d.Id));

        var usage = await db.Records.Where(r => r.DoctorId == me)
            .GroupBy(r => r.DiagnosisId)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);

        var list = await q.OrderBy(d => d.Code).ToListAsync();
        vm.Items = list.Select(d => new CatalogItem
            {
                Diagnosis = d,
                IsFavorite = favIds.Contains(d.Id),
                UsedCount = usage.GetValueOrDefault(d.Id)
            })
            .ToList();

        vm.CategoryOptions = (await visible.Select(d => d.Category).Distinct().ToListAsync())
            .Order().Select(c => new SelectListItem(c, c)).ToList();
        vm.FavoritesCount = favIds.Count;
        return View(vm);
    }

    /// <summary>Добавить диагноз в «Мои диагнозы» или убрать из них.</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Toggle(int id, string? returnUrl)
    {
        var me = Me;
        var exists = await db.Diagnoses.AnyAsync(d => d.Id == id && (d.OwnerDoctorId == null || d.OwnerDoctorId == me));
        if (!exists) return NotFound();

        var fav = await db.Favorites.FindAsync(me, id);
        if (fav == null)
            db.Favorites.Add(new DoctorFavorite { DoctorId = me, DiagnosisId = id });
        else
            db.Favorites.Remove(fav);
        await db.SaveChangesAsync();

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await FillCategoriesAsync();
        return View(new Diagnosis());
    }

    /// <summary>Личный диагноз врача (виден только ему), сразу попадает в «Мои диагнозы».</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Diagnosis model)
    {
        var me = Me;
        model.Code = model.Code?.Trim().ToUpperInvariant() ?? "";
        if (!string.IsNullOrEmpty(model.Code) && await db.Diagnoses.AnyAsync(d =>
                d.Code == model.Code && (d.OwnerDoctorId == null || d.OwnerDoctorId == me)))
            ModelState.AddModelError(nameof(model.Code), "Диагноз с таким кодом уже есть в справочнике");

        if (!ModelState.IsValid)
        {
            await FillCategoriesAsync();
            return View(model);
        }

        var diagnosis = new Diagnosis
        {
            Code = model.Code,
            Name = model.Name.Trim(),
            Category = model.Category.Trim(),
            OwnerDoctorId = me
        };
        db.Diagnoses.Add(diagnosis);
        db.Favorites.Add(new DoctorFavorite { DoctorId = me, Diagnosis = diagnosis });
        await db.SaveChangesAsync();

        TempData["Success"] = $"Диагноз {diagnosis.Code} добавлен в ваш справочник";
        return RedirectToAction(nameof(Index), new { OnlyMine = true });
    }

    /// <summary>Удалить личный диагноз (только если он ещё не использовался).</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var me = Me;
        var d = await db.Diagnoses.FirstOrDefaultAsync(x => x.Id == id && x.OwnerDoctorId == me);
        if (d == null) return NotFound();

        if (await db.Records.AnyAsync(r => r.DiagnosisId == id))
        {
            TempData["Error"] = "Нельзя удалить диагноз — он уже поставлен пациентам";
            return RedirectToAction(nameof(Index), new { OnlyMine = true });
        }

        db.Favorites.RemoveRange(db.Favorites.Where(f => f.DiagnosisId == id));
        db.Diagnoses.Remove(d);
        await db.SaveChangesAsync();
        TempData["Success"] = "Личный диагноз удалён";
        return RedirectToAction(nameof(Index), new { OnlyMine = true });
    }

    private async Task FillCategoriesAsync()
    {
        var me = Me;
        ViewBag.Categories = (await db.Diagnoses
                .Where(d => d.OwnerDoctorId == null || d.OwnerDoctorId == me)
                .Select(d => d.Category).Distinct().ToListAsync())
            .Order().ToList();
    }
}
