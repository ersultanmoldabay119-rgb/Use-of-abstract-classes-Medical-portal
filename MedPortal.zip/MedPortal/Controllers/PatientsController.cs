using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

[Authorize(Roles = Roles.Doctor)]
public class PatientsController(AppDbContext db) : Controller
{
    public async Task<IActionResult> Index(PatientListViewModel vm)
    {
        var me = User.GetDoctorId();
        var q = db.Patients.AsQueryable();

        if (!string.IsNullOrWhiteSpace(vm.Search))
        {
            var s = vm.Search.Trim().ToLowerInvariant();
            q = q.Where(p => p.FullNameLower.Contains(s) || p.Iin.Contains(s));
        }
        if (vm.OnlyMine)
            q = q.Where(p => p.Records.Any(r => r.DoctorId == me));

        vm.Items = await q.OrderBy(p => p.FullName)
            .Select(p => new PatientListItem
            {
                Patient = p,
                MyRecords = p.Records.Count(r => r.DoctorId == me),
                LastVisit = p.Records.Where(r => r.DoctorId == me).Max(r => (DateTime?)r.DiagnosedAt)
            })
            .ToListAsync();
        return View(vm);
    }

    public async Task<IActionResult> Details(int id)
    {
        var me = User.GetDoctorId();
        var patient = await db.Patients.FirstOrDefaultAsync(p => p.Id == id);
        if (patient == null) return NotFound();

        var records = await db.Records
            .Include(r => r.Diagnosis)
            .Where(r => r.PatientId == id && r.DoctorId == me)
            .OrderByDescending(r => r.DiagnosedAt)
            .ToListAsync();

        return View(new PatientDetailsViewModel { Patient = patient, Records = records });
    }

    [HttpGet]
    public IActionResult Create() => View(new Patient());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Patient model)
    {
        await ValidatePatientAsync(model);
        if (!ModelState.IsValid) return View(model);

        var patient = new Patient();
        Apply(model, patient);
        db.Patients.Add(patient);
        await db.SaveChangesAsync();

        TempData["Success"] = "Пациент добавлен";
        return RedirectToAction(nameof(Details), new { id = patient.Id });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var patient = await db.Patients.FindAsync(id);
        return patient == null ? NotFound() : View(patient);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Patient model)
    {
        var patient = await db.Patients.FindAsync(id);
        if (patient == null) return NotFound();

        model.Id = id;
        await ValidatePatientAsync(model);
        if (!ModelState.IsValid) return View(model);

        Apply(model, patient);
        await db.SaveChangesAsync();
        TempData["Success"] = "Данные пациента сохранены";
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task ValidatePatientAsync(Patient model)
    {
        if (!string.IsNullOrEmpty(model.Iin) &&
            await db.Patients.AnyAsync(p => p.Iin == model.Iin && p.Id != model.Id))
            ModelState.AddModelError(nameof(model.Iin), "Пациент с таким ИИН уже есть в базе");

        if (model.BirthDate > DateOnly.FromDateTime(DateTime.Today) || model.BirthDate.Year < 1900)
            ModelState.AddModelError(nameof(model.BirthDate), "Некорректная дата рождения");
    }

    private static void Apply(Patient from, Patient to)
    {
        to.FullName = from.FullName.Trim();
        to.Iin = from.Iin.Trim();
        to.BirthDate = from.BirthDate;
        to.Gender = from.Gender;
        to.Phone = from.Phone?.Trim();
        to.Address = from.Address?.Trim();
        to.Email = string.IsNullOrWhiteSpace(from.Email) ? null : from.Email.Trim();
        to.BloodGroup = string.IsNullOrWhiteSpace(from.BloodGroup) ? null : from.BloodGroup.Trim();
        to.Allergies = string.IsNullOrWhiteSpace(from.Allergies) ? null : from.Allergies.Trim();
    }
}
