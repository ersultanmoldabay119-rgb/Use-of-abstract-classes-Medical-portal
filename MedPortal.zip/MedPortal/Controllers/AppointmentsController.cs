using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

/// <summary>Приёмы врача: кто и на какое время записался. Врач видит только свои приёмы.</summary>
[Authorize(Roles = Roles.Doctor)]
public class AppointmentsController(AppDbContext db) : Controller
{
    private int Me => User.GetDoctorId();

    public async Task<IActionResult> Index(DoctorAppointmentsViewModel vm)
    {
        var me = Me;
        var now = DateTime.Now;
        var todayStart = DateTime.Today;
        var todayEnd = todayStart.AddDays(1);
        var mine = db.Appointments.Where(a => a.DoctorId == me);

        vm.TodayCount = await mine.CountAsync(a =>
            a.StartsAt >= todayStart && a.StartsAt < todayEnd && a.Status != AppointmentStatus.Cancelled);
        vm.UpcomingCount = await mine.CountAsync(a => a.StartsAt >= now && a.Status == AppointmentStatus.Scheduled);

        var q = mine.Include(a => a.Patient).AsQueryable();
        vm.Period = string.IsNullOrEmpty(vm.Period) ? "upcoming" : vm.Period;

        if (vm.Date.HasValue)
        {
            // Конкретная дата важнее периода
            var from = vm.Date.Value.ToDateTime(TimeOnly.MinValue);
            var to = from.AddDays(1);
            q = q.Where(a => a.StartsAt >= from && a.StartsAt < to);
            vm.Period = "all";
        }
        else
        {
            q = vm.Period switch
            {
                "today" => q.Where(a => a.StartsAt >= todayStart && a.StartsAt < todayEnd),
                "past" => q.Where(a => a.StartsAt < todayStart),
                "all" => q,
                _ => q.Where(a => a.StartsAt >= todayStart)
            };
        }

        if (vm.Status.HasValue) q = q.Where(a => a.Status == vm.Status);
        if (!string.IsNullOrWhiteSpace(vm.Search))
        {
            var s = vm.Search.Trim().ToLowerInvariant();
            q = q.Where(a => a.Patient!.FullNameLower.Contains(s) || a.Patient.Iin.Contains(s));
        }

        q = vm.Period == "past" ? q.OrderByDescending(a => a.StartsAt) : q.OrderBy(a => a.StartsAt);
        vm.Items = await q.Take(200).ToListAsync();
        return View(vm);
    }

    /// <summary>Сменить статус приёма: состоялся / неявка / отменён.</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SetStatus(int id, AppointmentStatus status, string? returnUrl)
    {
        var me = Me;
        var a = await db.Appointments.FirstOrDefaultAsync(x => x.Id == id && x.DoctorId == me);
        if (a == null) return NotFound();

        if (a.Status != AppointmentStatus.Scheduled || status == AppointmentStatus.Scheduled)
            TempData["Error"] = "Статус этого приёма уже нельзя изменить";
        else if (status is AppointmentStatus.Completed or AppointmentStatus.NoShow && a.StartsAt > DateTime.Now)
            TempData["Error"] = "Приём ещё не начался";
        else
        {
            a.Status = status;
            await db.SaveChangesAsync();
            TempData["Success"] = $"Приём отмечен: {status.DisplayName().ToLower()}";
        }

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
        return RedirectToAction(nameof(Index));
    }
}
