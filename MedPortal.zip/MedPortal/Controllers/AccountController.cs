using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

public class AccountController(AppDbContext db) : Controller
{
    private readonly PasswordHasher<Doctor> _doctorHasher = new();
    private readonly PasswordHasher<Patient> _patientHasher = new();

    // ---------- Вход (общий для врачей и пациентов) ----------
    [HttpGet]
    public IActionResult Login(string? returnUrl)
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var login = model.Login.Trim().ToLowerInvariant();
        var signedIn = false;

        // Врач входит по логину
        var doctor = await db.Doctors.FirstOrDefaultAsync(d => d.Login == login);
        if (doctor != null &&
            _doctorHasher.VerifyHashedPassword(doctor, doctor.PasswordHash, model.Password) != PasswordVerificationResult.Failed)
        {
            await AuthHelper.SignInDoctorAsync(HttpContext, doctor, model.RememberMe);
            signedIn = true;
        }

        // Пациент входит по ИИН
        if (!signedIn)
        {
            var patient = await db.Patients.FirstOrDefaultAsync(p => p.Iin == login && p.PasswordHash != null);
            if (patient != null &&
                _patientHasher.VerifyHashedPassword(patient, patient.PasswordHash!, model.Password) != PasswordVerificationResult.Failed)
            {
                await AuthHelper.SignInPatientAsync(HttpContext, patient, model.RememberMe);
                signedIn = true;
            }
        }

        if (!signedIn)
        {
            ModelState.AddModelError(string.Empty, "Неверный логин (ИИН) или пароль");
            return View(model);
        }

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);
        return RedirectToAction("Index", "Home");
    }

    // ---------- Регистрация врача ----------
    [HttpGet]
    public IActionResult Register()
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new RegisterViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        var login = (model.Login ?? "").Trim().ToLowerInvariant();
        if (ModelState.IsValid && await db.Doctors.AnyAsync(d => d.Login == login))
            ModelState.AddModelError(nameof(model.Login), "Этот логин уже занят");

        if (!ModelState.IsValid) return View(model);

        var doctor = new Doctor
        {
            Login = login,
            FullName = model.FullName.Trim(),
            Specialty = model.Specialty.Trim(),
            Organization = model.Organization?.Trim() ?? ""
        };
        doctor.PasswordHash = _doctorHasher.HashPassword(doctor, model.Password);
        db.Doctors.Add(doctor);
        await db.SaveChangesAsync();

        await AuthHelper.SignInDoctorAsync(HttpContext, doctor, false);
        TempData["Success"] = "Кабинет создан! Выберите диагнозы, с которыми вы работаете, — они появятся первыми при постановке диагноза.";
        return RedirectToAction("Index", "Catalog");
    }

    // ---------- Регистрация пациента ----------
    [HttpGet]
    public IActionResult RegisterPatient()
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new PatientRegisterViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> RegisterPatient(PatientRegisterViewModel model)
    {
        if (model.BirthDate is { } birth &&
            (birth > DateOnly.FromDateTime(DateTime.Today) || birth.Year < 1900))
            ModelState.AddModelError(nameof(model.BirthDate), "Некорректная дата рождения");

        if (!ModelState.IsValid) return View(model);

        var patient = await db.Patients.FirstOrDefaultAsync(p => p.Iin == model.Iin);
        if (patient != null && patient.HasAccount)
        {
            ModelState.AddModelError(nameof(model.Iin), "Личный кабинет для этого ИИН уже создан — войдите с паролем");
            return View(model);
        }

        if (patient != null)
        {
            // Пациент уже есть в реестре (его внёс врач). Подтверждаем личность по телефону из карты.
            var onFile = patient.Phone.PhoneDigits();
            if (onFile.Length == 0 || onFile != model.Phone.PhoneDigits())
            {
                ModelState.AddModelError(nameof(model.Phone),
                    "Пациент с таким ИИН уже есть в реестре. Укажите номер телефона, записанный в вашей медицинской карте, или обратитесь к врачу.");
                return View(model);
            }
        }
        else
        {
            patient = new Patient
            {
                FullName = model.FullName.Trim(),
                Iin = model.Iin,
                BirthDate = model.BirthDate!.Value,
                Gender = model.Gender,
                Phone = model.Phone.Trim()
            };
            db.Patients.Add(patient);
        }

        patient.PasswordHash = _patientHasher.HashPassword(patient, model.Password);
        await db.SaveChangesAsync();

        await AuthHelper.SignInPatientAsync(HttpContext, patient, false);
        TempData["Success"] = "Личный кабинет создан. Теперь вы можете записаться на приём и видеть свои диагнозы.";
        return RedirectToAction("Index", "My");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Home");
    }
}
