using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

/// <summary>Личный кабинет врача: сводка и профиль.</summary>
[Authorize(Roles = Roles.Doctor)]
public class CabinetController(AppDbContext db) : Controller
{
    public async Task<IActionResult> Index()
    {
        var me = User.GetDoctorId();
        var doctor = await db.Doctors.FirstAsync(d => d.Id == me);
        var myRecords = db.Records.Where(r => r.DoctorId == me);
        var monthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

        var vm = new DashboardViewModel
        {
            Doctor = doctor,
            TotalRecords = await myRecords.CountAsync(),
            PatientsCount = await myRecords.Select(r => r.PatientId).Distinct().CountAsync(),
            ThisMonth = await myRecords.CountAsync(r => r.DiagnosedAt >= monthStart),
            ActiveCount = await myRecords.CountAsync(r => r.Status != DiagnosisStatus.Recovered),
            FavoritesCount = await db.Favorites.CountAsync(f => f.DoctorId == me),
            Recent = await myRecords
                .Include(r => r.Patient).Include(r => r.Diagnosis)
                .OrderByDescending(r => r.DiagnosedAt).Take(6).ToListAsync(),
            Top = (await myRecords
                    .GroupBy(r => new { r.Diagnosis!.Code, r.Diagnosis.Name })
                    .Select(g => new { g.Key.Code, g.Key.Name, Count = g.Count() })
                    .OrderByDescending(x => x.Count).Take(5).ToListAsync())
                .Select(x => new TopDiagnosisItem(x.Code, x.Name, x.Count)).ToList()
        };

        // Записи пациентов на приём к этому врачу
        var now = DateTime.Now;
        var todayStart = DateTime.Today;
        var todayEnd = todayStart.AddDays(1);
        var myAppointments = db.Appointments.Where(a => a.DoctorId == me);
        vm.TodayAppointments = await myAppointments.CountAsync(a =>
            a.StartsAt >= todayStart && a.StartsAt < todayEnd && a.Status != AppointmentStatus.Cancelled);
        vm.Upcoming = await myAppointments
            .Include(a => a.Patient)
            .Where(a => a.Status == AppointmentStatus.Scheduled && a.StartsAt >= now)
            .OrderBy(a => a.StartsAt).Take(5).ToListAsync();

        return View(vm);
    }

    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var doctor = await db.Doctors.FirstAsync(d => d.Id == User.GetDoctorId());
        return View(new ProfileViewModel
        {
            Login = doctor.Login,
            FullName = doctor.FullName,
            Specialty = doctor.Specialty,
            Organization = doctor.Organization,
            Room = doctor.Room,
            IsOnlineAvailable = doctor.IsOnlineAvailable,
            OnlineConsultationUrl = doctor.OnlineConsultationUrl
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        var doctor = await db.Doctors.FirstAsync(d => d.Id == User.GetDoctorId());
        model.Login = doctor.Login;
        var hasher = new PasswordHasher<Doctor>();

        var changePassword = !string.IsNullOrEmpty(model.NewPassword);
        if (changePassword)
        {
            if (string.IsNullOrEmpty(model.CurrentPassword) ||
                hasher.VerifyHashedPassword(doctor, doctor.PasswordHash, model.CurrentPassword) == PasswordVerificationResult.Failed)
                ModelState.AddModelError(nameof(model.CurrentPassword), "Текущий пароль указан неверно");
        }

        if (!ModelState.IsValid) return View(model);

        doctor.FullName = model.FullName.Trim();
        doctor.Specialty = model.Specialty.Trim();
        doctor.Organization = model.Organization?.Trim() ?? "";
        doctor.Room = model.Room?.Trim() ?? "";
        doctor.IsOnlineAvailable = model.IsOnlineAvailable;
        doctor.OnlineConsultationUrl = string.IsNullOrWhiteSpace(model.OnlineConsultationUrl) ? null : model.OnlineConsultationUrl.Trim();
        if (changePassword) doctor.PasswordHash = hasher.HashPassword(doctor, model.NewPassword!);
        await db.SaveChangesAsync();

        // Обновляем данные в cookie (ФИО и специальность показываются в шапке)
        await AuthHelper.SignInDoctorAsync(HttpContext, doctor, false);

        TempData["Success"] = changePassword ? "Профиль и пароль обновлены" : "Профиль обновлён";
        return RedirectToAction(nameof(Profile));
    }
}
