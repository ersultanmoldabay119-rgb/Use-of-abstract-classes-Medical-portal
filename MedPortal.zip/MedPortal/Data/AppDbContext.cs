using MedPortal.Models;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Diagnosis> Diagnoses => Set<Diagnosis>();
    public DbSet<DoctorFavorite> Favorites => Set<DoctorFavorite>();
    public DbSet<PatientDiagnosis> Records => Set<PatientDiagnosis>();
    public DbSet<Appointment> Appointments => Set<Appointment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Doctor>().HasIndex(d => d.Login).IsUnique();

        b.Entity<Patient>().HasIndex(p => p.Iin).IsUnique();
        b.Entity<Patient>().HasIndex(p => p.FullNameLower);

        b.Entity<Diagnosis>().HasIndex(d => d.Code);
        b.Entity<Diagnosis>()
            .HasOne(d => d.OwnerDoctor).WithMany()
            .HasForeignKey(d => d.OwnerDoctorId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<DoctorFavorite>().HasKey(f => new { f.DoctorId, f.DiagnosisId });
        b.Entity<DoctorFavorite>()
            .HasOne(f => f.Doctor).WithMany(d => d.Favorites)
            .HasForeignKey(f => f.DoctorId);
        b.Entity<DoctorFavorite>()
            .HasOne(f => f.Diagnosis).WithMany()
            .HasForeignKey(f => f.DiagnosisId);

        b.Entity<PatientDiagnosis>()
            .HasOne(r => r.Doctor).WithMany(d => d.Records)
            .HasForeignKey(r => r.DoctorId);
        b.Entity<PatientDiagnosis>()
            .HasOne(r => r.Patient).WithMany(p => p.Records)
            .HasForeignKey(r => r.PatientId);
        b.Entity<PatientDiagnosis>()
            .HasOne(r => r.Diagnosis).WithMany()
            .HasForeignKey(r => r.DiagnosisId)
            .OnDelete(DeleteBehavior.Restrict);
        b.Entity<PatientDiagnosis>().HasIndex(r => new { r.DoctorId, r.DiagnosedAt });

        b.Entity<Appointment>()
            .HasOne(a => a.Doctor).WithMany(d => d.Appointments)
            .HasForeignKey(a => a.DoctorId);
        b.Entity<Appointment>()
            .HasOne(a => a.Patient).WithMany(p => p.Appointments)
            .HasForeignKey(a => a.PatientId);
        // Один врач — одно время — одна (не отменённая) запись
        b.Entity<Appointment>()
            .HasIndex(a => new { a.DoctorId, a.StartsAt }).IsUnique()
            .HasFilter("\"Status\" <> 2");
    }

    public override int SaveChanges(bool acceptAllChangesOnSuccess)
    {
        FillSearchFields();
        return base.SaveChanges(acceptAllChangesOnSuccess);
    }

    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken ct = default)
    {
        FillSearchFields();
        return base.SaveChangesAsync(acceptAllChangesOnSuccess, ct);
    }

    // SQLite не умеет регистронезависимый поиск по кириллице, поэтому храним копию в нижнем регистре.
    private void FillSearchFields()
    {
        foreach (var e in ChangeTracker.Entries<Patient>())
            if (e.State is EntityState.Added or EntityState.Modified)
                e.Entity.FullNameLower = e.Entity.FullName.Trim().ToLowerInvariant();

        foreach (var e in ChangeTracker.Entries<Diagnosis>())
            if (e.State is EntityState.Added or EntityState.Modified)
                e.Entity.SearchText = $"{e.Entity.Code} {e.Entity.Name} {e.Entity.Category}".ToLowerInvariant();
    }
}
