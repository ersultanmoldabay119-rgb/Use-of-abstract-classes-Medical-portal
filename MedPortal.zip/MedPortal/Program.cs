using System.Globalization;
using System.Security.Claims;
using MedPortal.Data;
using MedPortal.Infrastructure;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Не кодировать кириллицу в HTML как &#x...;
builder.Services.Configure<Microsoft.Extensions.WebEncoders.WebEncoderOptions>(o =>
    o.TextEncoderSettings = new System.Text.Encodings.Web.TextEncoderSettings(System.Text.Unicode.UnicodeRanges.All));

// SQLite
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default")));

// Вход врачей и пациентов по cookie (роль хранится в cookie)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/"; // чужой раздел -> главная -> свой кабинет
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
        options.Cookie.Name = "MedPortal.Auth";

        // Если пользователя больше нет в БД (например, базу пересоздали) или cookie старого формата — сбрасываем вход
        options.Events.OnValidatePrincipal = async ctx =>
        {
            var user = ctx.Principal;
            var db = ctx.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
            var valid = int.TryParse(user?.FindFirstValue(ClaimTypes.NameIdentifier), out var id);
            if (valid && user!.IsInRole(Roles.Doctor))
                valid = await db.Doctors.AnyAsync(d => d.Id == id);
            else if (valid && user!.IsInRole(Roles.Patient))
                valid = await db.Patients.AnyAsync(p => p.Id == id && p.PasswordHash != null);
            else
                valid = false;

            if (!valid)
            {
                ctx.RejectPrincipal();
                await ctx.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            }
        };
    });
builder.Services.AddAuthorization();

var app = builder.Build();

// Создаём БД и заполняем демо-данными при первом запуске
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    SchemaUpgrader.Upgrade(db); // новые колонки и таблицы для базы, созданной прежней версией
    DbSeeder.Seed(db);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

var ru = new CultureInfo("ru-RU");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(ru),
    SupportedCultures = [ru],
    SupportedUICultures = [ru]
});

if (!app.Environment.IsDevelopment())
    app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
