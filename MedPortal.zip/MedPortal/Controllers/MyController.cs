using MedPortal.Data;
using MedPortal.Infrastructure;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

/// <summary>
/// Личный кабинет пациента: свои диагнозы, запись на приём, свои данные.
/// Пациент видит только то, что относится к нему самому.
/// </summary>
[Authorize(Roles = Roles.Patient)]
public class MyController(AppDbContext db) : Controller
{
    private int Me => User.GetPatientId();

    // ---------- Главная ----------
    public async Task<IActionResult> Index()
    {
        var me = Me;
        var now = DateTime.Now;
        var patient = await db.Patients.FirstAsync(p => p.Id == me);
        var myRecords = db.Records.Where(r => r.PatientId == me);
        var upcoming = db.Appointments.Where(a =>
            a.PatientId == me && a.Status == AppointmentStatus.Scheduled && a.StartsAt >= now);

        var vm = new PatientHomeViewModel
        {
            Patient = patient,
            UpcomingCount = await upcoming.CountAsync(),
            Upcoming = await upcoming.Include(a => a.Doctor).OrderBy(a => a.StartsAt).Take(4).ToListAsync(),
            DiagnosesCount = await myRecords.CountAsync(),
            ActiveCount = await myRecords.CountAsync(r => r.Status != DiagnosisStatus.Recovered),
            DoctorsCount = await myRecords.Select(r => r.DoctorId).Distinct().CountAsync(),
            RecentDiagnoses = await myRecords
                .Include(r => r.Diagnosis).Include(r => r.Doctor)
                .OrderByDescending(r => r.DiagnosedAt).Take(5).ToListAsync()
        };
        return View(vm);
    }

    // ---------- Мои диагнозы ----------
    public async Task<IActionResult> Diagnoses(PatientDiagnosesViewModel vm)
    {
        var me = Me;
        var q = db.Records
            .Include(r => r.Diagnosis).Include(r => r.Doctor)
            .Where(r => r.PatientId == me);

        if (!string.IsNullOrWhiteSpace(vm.Search))
        {
            var s = vm.Search.Trim().ToLowerInvariant();
            q = q.Where(r => r.Diagnosis!.SearchText.Contains(s));
        }
        if (vm.DoctorId.HasValue) q = q.Where(r => r.DoctorId == vm.DoctorId);
        if (vm.Status.HasValue) q = q.Where(r => r.Status == vm.Status);
        if (vm.DateFrom.HasValue)
        {
            var from = vm.DateFrom.Value.ToDateTime(TimeOnly.MinValue);
            q = q.Where(r => r.DiagnosedAt >= from);
        }
        if (vm.DateTo.HasValue)
        {
            var to = vm.DateTo.Value.AddDays(1).ToDateTime(TimeOnly.MinValue);
            q = q.Where(r => r.DiagnosedAt < to);
        }

        vm.Items = await q.OrderByDescending(r => r.DiagnosedAt).ToListAsync();
        vm.Total = vm.Items.Count;

        var doctors = await db.Records.Where(r => r.PatientId == me)
            .Select(r => r.Doctor!).Distinct().OrderBy(d => d.FullName).ToListAsync();
        vm.DoctorOptions = doctors
            .Select(d => new SelectListItem($"{d.FullName} — {d.Specialty}", d.Id.ToString())).ToList();
        return View(vm);
    }

    // ---------- Мои записи на приём ----------
    public async Task<IActionResult> Appointments()
    {
        var me = Me;
        var now = DateTime.Now;
        var all = await db.Appointments.Include(a => a.Doctor)
            .Where(a => a.PatientId == me)
            .OrderBy(a => a.StartsAt).ToListAsync();

        return View(new PatientAppointmentsViewModel
        {
            Upcoming = all.Where(a => a.Status == AppointmentStatus.Scheduled && a.StartsAt >= now).ToList(),
            Past = all.Where(a => !(a.Status == AppointmentStatus.Scheduled && a.StartsAt >= now))
                .OrderByDescending(a => a.StartsAt).ToList()
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(int id)
    {
        var me = Me;
        var a = await db.Appointments.FirstOrDefaultAsync(x => x.Id == id && x.PatientId == me);
        if (a == null) return NotFound();

        if (a.Status != AppointmentStatus.Scheduled || a.StartsAt < DateTime.Now)
            TempData["Error"] = "Эту запись уже нельзя отменить";
        else
        {
            a.Status = AppointmentStatus.Cancelled;
            await db.SaveChangesAsync();
            TempData["Success"] = "Запись на приём отменена";
        }
        return RedirectToAction(nameof(Appointments));
    }

    // ---------- Запись на приём: врач → день → время ----------
    [HttpGet]
    public async Task<IActionResult> Book(BookViewModel vm)
    {
        ModelState.Clear();
        await FillBookAsync(vm);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken, ActionName("Book")]
    public async Task<IActionResult> BookPost(BookViewModel vm)
    {
        var me = Me;
        var doctor = vm.DoctorId.HasValue ? await db.Doctors.FindAsync(vm.DoctorId.Value) : null;

        if (doctor == null)
            ModelState.AddModelError(string.Empty, "Выберите врача");
        else if (vm.StartsAt is not { } time)
            ModelState.AddModelError(string.Empty, "Выберите время приёма");
        else if (!Schedule.IsBookable(time))
            ModelState.AddModelError(string.Empty, "На это время записаться нельзя — выберите другое");
        else if (await db.Appointments.AnyAsync(a =>
                     a.DoctorId == doctor.Id && a.StartsAt == time && a.Status != AppointmentStatus.Cancelled))
            ModelState.AddModelError(string.Empty, "Это время только что заняли — выберите другое");
        else if (await db.Appointments.AnyAsync(a =>
                     a.PatientId == me && a.StartsAt == time && a.Status == AppointmentStatus.Scheduled))
            ModelState.AddModelError(string.Empty, "У вас уже есть запись к другому врачу на это время");
        else if (vm.IsOnline && !doctor.IsOnlineAvailable)
            ModelState.AddModelError(string.Empty, "Этот врач не проводит онлайн-консультации");

        if (ModelState.IsValid)
        {
            var isOnline = vm.IsOnline && doctor!.IsOnlineAvailable;
            var timeVal = vm.StartsAt!.Value;
            db.Appointments.Add(new Appointment
            {
                PatientId = me,
                DoctorId = doctor!.Id,
                StartsAt = timeVal,
                IsOnline = isOnline,
                OnlineLink = isOnline ? doctor.BuildConsultationLink(timeVal) : null,
                Reason = string.IsNullOrWhiteSpace(vm.Reason) ? null : vm.Reason.Trim()
            });
            try
            {
                await db.SaveChangesAsync();
                var formatText = isOnline ? " (онлайн-консультация)" : "";
                TempData["Success"] =
                    $"Вы записаны к врачу {doctor.FullName} на {timeVal:d MMMM} в {timeVal:HH:mm}{formatText}";
                return RedirectToAction(nameof(Appointments));
            }
            catch (DbUpdateException)
            {
                // Сработал уникальный индекс: время заняли одновременно с нами
                db.ChangeTracker.Clear();
                ModelState.AddModelError(string.Empty, "Это время только что заняли — выберите другое");
            }
        }

        if (vm.StartsAt.HasValue) vm.Date ??= DateOnly.FromDateTime(vm.StartsAt.Value);
        await FillBookAsync(vm);
        return View(vm);
    }

    private async Task FillBookAsync(BookViewModel vm)
    {
        var doctors = await db.Doctors.OrderBy(d => d.Specialty).ThenBy(d => d.FullName).ToListAsync();
        vm.Specialties = doctors.Select(d => d.Specialty).Where(s => s != "").Distinct().Order().ToList();
        vm.Doctors = string.IsNullOrEmpty(vm.Specialty)
            ? doctors
            : doctors.Where(d => d.Specialty == vm.Specialty).ToList();

        vm.Doctor = vm.DoctorId.HasValue ? doctors.FirstOrDefault(d => d.Id == vm.DoctorId) : null;
        if (vm.Doctor == null)
        {
            vm.DoctorId = null;
            return;
        }

        // Занятые времена врача в окне записи
        var doctorId = vm.Doctor.Id;
        var days = Schedule.BookableDays();
        var from = days.First().ToDateTime(TimeOnly.MinValue);
        var taken = (await db.Appointments
                .Where(a => a.DoctorId == doctorId && a.Status != AppointmentStatus.Cancelled && a.StartsAt >= from)
                .Select(a => a.StartsAt).ToListAsync())
            .ToHashSet();

        var now = DateTime.Now;
        bool IsFree(DateTime t) => t > now && !taken.Contains(t);

        vm.Days = days.Select(d => new BookDay(d, Schedule.SlotsFor(d).Count(IsFree))).ToList();

        // По умолчанию — ближайший день со свободным временем
        if (vm.Date == null || !days.Contains(vm.Date.Value))
            vm.Date = vm.Days.FirstOrDefault(d => d.FreeCount > 0)?.Date ?? days.First();

        vm.Slots = Schedule.SlotsFor(vm.Date.Value).Select(t => new BookSlot(t, IsFree(t))).ToList();
    }

    // ---------- Мои данные ----------
    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var patient = await db.Patients.FirstAsync(p => p.Id == Me);
        return View(new PatientProfileViewModel
        {
            Patient = patient,
            Phone = patient.Phone,
            Email = patient.Email,
            Address = patient.Address
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(PatientProfileViewModel model)
    {
        var patient = await db.Patients.FirstAsync(p => p.Id == Me);
        model.Patient = patient;
        var hasher = new PasswordHasher<Patient>();

        var changePassword = !string.IsNullOrEmpty(model.NewPassword);
        if (changePassword &&
            (string.IsNullOrEmpty(model.CurrentPassword) ||
             hasher.VerifyHashedPassword(patient, patient.PasswordHash!, model.CurrentPassword) == PasswordVerificationResult.Failed))
            ModelState.AddModelError(nameof(model.CurrentPassword), "Текущий пароль указан неверно");

        if (!ModelState.IsValid) return View(model);

        patient.Phone = model.Phone?.Trim();
        patient.Email = string.IsNullOrWhiteSpace(model.Email) ? null : model.Email.Trim();
        patient.Address = string.IsNullOrWhiteSpace(model.Address) ? null : model.Address.Trim();
        if (changePassword) patient.PasswordHash = hasher.HashPassword(patient, model.NewPassword!);
        await db.SaveChangesAsync();

        TempData["Success"] = changePassword ? "Данные и пароль обновлены" : "Данные обновлены";
        return RedirectToAction(nameof(Profile));
    }
}
