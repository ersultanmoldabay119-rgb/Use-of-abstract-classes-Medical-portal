using Microsoft.EntityFrameworkCore;

namespace MedPortal.Data;

/// <summary>
/// Дополняет уже существующую базу новыми колонками и таблицами, не удаляя данные.
/// (База создаётся через EnsureCreated, а он не обновляет схему существующего файла.)
/// </summary>
public static class SchemaUpgrader
{
    public static void Upgrade(AppDbContext db)
    {
        AddColumnIfMissing(db, "Doctors", "Room", "TEXT NOT NULL DEFAULT ''");
        AddColumnIfMissing(db, "Doctors", "IsOnlineAvailable", "INTEGER NOT NULL DEFAULT 1");
        AddColumnIfMissing(db, "Doctors", "OnlineConsultationUrl", "TEXT NULL");

        AddColumnIfMissing(db, "Patients", "Email", "TEXT NULL");
        AddColumnIfMissing(db, "Patients", "BloodGroup", "TEXT NULL");
        AddColumnIfMissing(db, "Patients", "Allergies", "TEXT NULL");
        AddColumnIfMissing(db, "Patients", "PasswordHash", "TEXT NULL");

        db.Database.ExecuteSqlRaw("""
            CREATE TABLE IF NOT EXISTS "Appointments" (
                "Id" INTEGER NOT NULL CONSTRAINT "PK_Appointments" PRIMARY KEY AUTOINCREMENT,
                "PatientId" INTEGER NOT NULL,
                "DoctorId" INTEGER NOT NULL,
                "StartsAt" TEXT NOT NULL,
                "Status" INTEGER NOT NULL,
                "Reason" TEXT NULL,
                "CreatedAt" TEXT NOT NULL,
                CONSTRAINT "FK_Appointments_Doctors_DoctorId" FOREIGN KEY ("DoctorId") REFERENCES "Doctors" ("Id") ON DELETE CASCADE,
                CONSTRAINT "FK_Appointments_Patients_PatientId" FOREIGN KEY ("PatientId") REFERENCES "Patients" ("Id") ON DELETE CASCADE
            );
            """);
        db.Database.ExecuteSqlRaw("""
            CREATE UNIQUE INDEX IF NOT EXISTS "IX_Appointments_DoctorId_StartsAt"
                ON "Appointments" ("DoctorId", "StartsAt") WHERE "Status" <> 2;
            """);
        db.Database.ExecuteSqlRaw("""
            CREATE INDEX IF NOT EXISTS "IX_Appointments_PatientId" ON "Appointments" ("PatientId");
            """);

        AddColumnIfMissing(db, "Appointments", "IsOnline", "INTEGER NOT NULL DEFAULT 0");
        AddColumnIfMissing(db, "Appointments", "OnlineLink", "TEXT NULL");
    }

    private static void AddColumnIfMissing(AppDbContext db, string table, string column, string definition)
    {
        var connection = db.Database.GetDbConnection();
        var wasClosed = connection.State != System.Data.ConnectionState.Open;
        if (wasClosed) connection.Open();
        try
        {
            using var check = connection.CreateCommand();
            check.CommandText = $"SELECT COUNT(*) FROM pragma_table_info('{table}') WHERE name = '{column}'";
            var exists = Convert.ToInt32(check.ExecuteScalar()) > 0;
            if (exists) return;

            using var alter = connection.CreateCommand();
            alter.CommandText = $"ALTER TABLE \"{table}\" ADD COLUMN \"{column}\" {definition}";
            alter.ExecuteNonQuery();
        }
        finally
        {
            if (wasClosed) connection.Close();
        }
    }
}
