using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace MedPortal.Models;

/// <summary>
/// Интерфейс, описывающий возможность проведения онлайн-консультаций.
/// (Не содержит обычных полей и конструкторов экземпляра, но может содержать реализацию методов по правилам C#.)
/// </summary>
public interface IOnlineConsultation
{
    /// <summary>Доступна ли у врача запись на онлайн-консультацию.</summary>
    bool IsOnlineAvailable { get; set; }

    /// <summary>Персональная ссылка врача на комнату видеоконсультаций (если указана).</summary>
    string? OnlineConsultationUrl { get; set; }

    /// <summary>Реализация метода в интерфейсе по правилам C#: формирует ссылку на онлайн-приём.</summary>
    string GetConsultationLink(string doctorLogin, DateTime startsAt) =>
        !string.IsNullOrWhiteSpace(OnlineConsultationUrl)
            ? OnlineConsultationUrl.Trim()
            : $"https://meet.jit.si/medportal-{doctorLogin}-{startsAt:yyyyMMdd-HHmm}";
}

/// <summary>
/// Абстрактный базовый класс медицинского специалиста.
/// (Содержит поля экземпляра, конструктор и готовые методы; класс может наследовать только один такой класс.)
/// </summary>
public abstract class MedicalSpecialist
{
    // Поля экземпляра (доступны в абстрактном классе)
    private string _fullName = "";
    private string _specialty = "";

    protected MedicalSpecialist()
    {
        CreatedAt = DateTime.Now;
    }

    protected MedicalSpecialist(string fullName, string specialty) : this()
    {
        _fullName = fullName;
        _specialty = specialty;
    }

    public int Id { get; set; }

    [Required, StringLength(150)]
    public string FullName
    {
        get => _fullName;
        set => _fullName = value;
    }

    [StringLength(100)]
    public string Specialty
    {
        get => _specialty;
        set => _specialty = value;
    }

    [StringLength(200)]
    public string Organization { get; set; } = "";

    public DateTime CreatedAt { get; set; }

    /// <summary>Готовый метод абстрактного класса.</summary>
    public string GetWorkplaceSummary() =>
        string.IsNullOrWhiteSpace(Organization) ? Specialty : $"{Specialty} · {Organization}";

    /// <summary>Абстрактный метод, который обязан реализовать класс-наследник.</summary>
    public abstract string GetConsultationFormatInfo();
}

/// <summary>Врач — владелец личного кабинета (наследует абстрактный класс и реализует интерфейс IOnlineConsultation).</summary>
public class Doctor : MedicalSpecialist, IOnlineConsultation
{
    public Doctor()
    {
    }

    public Doctor(string fullName, string specialty) : base(fullName, specialty)
    {
    }

    [Required, StringLength(50)]
    public string Login { get; set; } = "";

    public string PasswordHash { get; set; } = "";

    /// <summary>Номер кабинета, где врач ведёт приём.</summary>
    [StringLength(20)]
    public string Room { get; set; } = "";

    /// <summary>Проводит ли врач онлайн-консультации (реализация IOnlineConsultation).</summary>
    [Display(Name = "Провожу онлайн-консультации")]
    public bool IsOnlineAvailable { get; set; } = true;

    /// <summary>Ссылка на видеокомнату для онлайн-консультаций (реализация IOnlineConsultation).</summary>
    [Display(Name = "Ссылка на онлайн-консультацию")]
    [StringLength(300)]
    public string? OnlineConsultationUrl { get; set; }

    public List<DoctorFavorite> Favorites { get; set; } = new();
    public List<PatientDiagnosis> Records { get; set; } = new();
    public List<Appointment> Appointments { get; set; } = new();

    public override string GetConsultationFormatInfo() =>
        IsOnlineAvailable
            ? (string.IsNullOrEmpty(Room) ? "Онлайн и очно" : $"Каб. {Room} / Онлайн")
            : (string.IsNullOrEmpty(Room) ? "Очный приём" : $"Каб. {Room}");

    public string BuildConsultationLink(DateTime startsAt) =>
        ((IOnlineConsultation)this).GetConsultationLink(Login, startsAt);
}

public enum Gender
{
    [Display(Name = "Мужской")] Male,
    [Display(Name = "Женский")] Female
}

/// <summary>Пациент (общий реестр прикреплённого населения).</summary>
public class Patient
{
    public int Id { get; set; }

    [Display(Name = "ФИО пациента")]
    [Required(ErrorMessage = "Укажите ФИО пациента")]
    [StringLength(150)]
    public string FullName { get; set; } = "";

    /// <summary>ФИО в нижнем регистре — для поиска по кириллице в SQLite.</summary>
    [ValidateNever]
    public string FullNameLower { get; set; } = "";

    [Display(Name = "ИИН")]
    [Required(ErrorMessage = "Укажите ИИН")]
    [RegularExpression(@"^\d{12}$", ErrorMessage = "ИИН должен состоять из 12 цифр")]
    public string Iin { get; set; } = "";

    [Display(Name = "Дата рождения")]
    [DataType(DataType.Date)]
    public DateOnly BirthDate { get; set; } = new(1990, 1, 1);

    [Display(Name = "Пол")]
    public Gender Gender { get; set; }

    [Display(Name = "Телефон")]
    [StringLength(30)]
    public string? Phone { get; set; }

    [Display(Name = "Адрес")]
    [StringLength(250)]
    public string? Address { get; set; }

    [Display(Name = "E-mail")]
    [EmailAddress(ErrorMessage = "Некорректный e-mail")]
    [StringLength(120)]
    public string? Email { get; set; }

    [Display(Name = "Группа крови")]
    [StringLength(20)]
    public string? BloodGroup { get; set; }

    [Display(Name = "Аллергии и непереносимость")]
    [StringLength(500)]
    public string? Allergies { get; set; }

    /// <summary>Хеш пароля. null — пациент есть в реестре, но личный кабинет ещё не создан.</summary>
    [ValidateNever]
    public string? PasswordHash { get; set; }

    public bool HasAccount => !string.IsNullOrEmpty(PasswordHash);

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    [ValidateNever]
    public List<PatientDiagnosis> Records { get; set; } = new();

    [ValidateNever]
    public List<Appointment> Appointments { get; set; } = new();

    public int Age
    {
        get
        {
            var today = DateOnly.FromDateTime(DateTime.Today);
            var age = today.Year - BirthDate.Year;
            if (BirthDate > today.AddYears(-age)) age--;
            return age;
        }
    }
}

/// <summary>Диагноз из справочника МКБ-10 (общий) или личный диагноз врача (OwnerDoctorId != null).</summary>
public class Diagnosis
{
    public int Id { get; set; }

    [Display(Name = "Код МКБ-10")]
    [Required(ErrorMessage = "Укажите код")]
    [StringLength(10)]
    public string Code { get; set; } = "";

    [Display(Name = "Наименование")]
    [Required(ErrorMessage = "Укажите наименование")]
    [StringLength(250)]
    public string Name { get; set; } = "";

    [Display(Name = "Раздел (класс болезней)")]
    [Required(ErrorMessage = "Укажите раздел")]
    [StringLength(150)]
    public string Category { get; set; } = "";

    /// <summary>Код + наименование в нижнем регистре — для поиска.</summary>
    [ValidateNever]
    public string SearchText { get; set; } = "";

    /// <summary>Если задан — диагноз добавлен врачом лично и виден только ему.</summary>
    public int? OwnerDoctorId { get; set; }

    [ValidateNever]
    public Doctor? OwnerDoctor { get; set; }

    public string Title => $"{Code} — {Name}";
}

/// <summary>Диагноз, выбранный врачом в свой личный справочник («Мои диагнозы»).</summary>
public class DoctorFavorite
{
    public int DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    public int DiagnosisId { get; set; }
    public Diagnosis? Diagnosis { get; set; }

    public DateTime AddedAt { get; set; } = DateTime.Now;
}

public enum DiagnosisType
{
    [Display(Name = "Предварительный")] Preliminary,
    [Display(Name = "Заключительный")] Final,
    [Display(Name = "Сопутствующий")] Concomitant
}

public enum DiagnosisStatus
{
    [Display(Name = "Активный")] Active,
    [Display(Name = "Хронический")] Chronic,
    [Display(Name = "Выздоровление")] Recovered
}

/// <summary>Диагноз, поставленный врачом пациенту.</summary>
public class PatientDiagnosis
{
    public int Id { get; set; }

    public int DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    public int PatientId { get; set; }
    public Patient? Patient { get; set; }

    public int DiagnosisId { get; set; }
    public Diagnosis? Diagnosis { get; set; }

    public DateTime DiagnosedAt { get; set; } = DateTime.Now;
    public DiagnosisType Type { get; set; } = DiagnosisType.Final;
    public DiagnosisStatus Status { get; set; } = DiagnosisStatus.Active;

    [StringLength(1000)]
    public string? Comment { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}

public enum AppointmentStatus
{
    [Display(Name = "Запланирован")] Scheduled,
    [Display(Name = "Состоялся")] Completed,
    [Display(Name = "Отменён")] Cancelled,
    [Display(Name = "Неявка")] NoShow
}

/// <summary>Запись пациента на приём к врачу.</summary>
public class Appointment
{
    public int Id { get; set; }

    public int PatientId { get; set; }
    public Patient? Patient { get; set; }

    public int DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    /// <summary>Дата и время начала приёма.</summary>
    public DateTime StartsAt { get; set; }

    public AppointmentStatus Status { get; set; } = AppointmentStatus.Scheduled;

    /// <summary>Причина обращения (жалобы), которую указал пациент.</summary>
    [StringLength(500)]
    public string? Reason { get; set; }

    /// <summary>Признак онлайн-консультации (true — онлайн по видеосвязи, false — очно в кабинете).</summary>
    public bool IsOnline { get; set; }

    /// <summary>Ссылка для подключения к онлайн-консультации.</summary>
    [StringLength(300)]
    public string? OnlineLink { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
